$(function () {
  $("#continue-btn").click(function () {
    var ref_number = $('#refnumber').val();
    $.ajax({
      url: "http://localhost:8080/customer/" + ref_number,
      type: "GET",
      success: function (data) {
        $("#Status").val(data.status);
        $("#custName").val(data.customerName);
        $("#due").val(data.amountDue);
        $("#errorAlert").fadeOut(1000);
        $(".register-right").fadeIn(1000);
      },
      error: function () {
        $(".register-right").fadeOut(200);
        $("#errorAlert").fadeIn(1000);
      },
    });    
  });
});
