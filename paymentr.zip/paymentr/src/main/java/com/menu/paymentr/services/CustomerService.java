package com.menu.paymentr.services;

import java.util.Optional;

import org.springframework.stereotype.Service;

import com.menu.paymentr.model.Customer;
import com.menu.paymentr.repository.CustomerRepository;

@Service
public class CustomerService {

	private CustomerRepository customerRepository;

	public CustomerService(CustomerRepository customerRepository) {
		this.customerRepository = customerRepository;
	}

	public Customer getCustomerDetails(String trackingId) {
		Optional<Customer> customerOpt = customerRepository.findById(trackingId);
		if (customerOpt.isPresent()) {
			return customerOpt.get();
		}
		return null;
	}
}
