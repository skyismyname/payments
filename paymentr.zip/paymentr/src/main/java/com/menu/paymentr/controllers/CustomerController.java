package com.menu.paymentr.controllers;

import java.util.Objects;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import com.menu.paymentr.model.Customer;
import com.menu.paymentr.services.CustomerService;

@Controller
@RequestMapping("/customer")
public class CustomerController {
	private CustomerService customerService;

	public CustomerController(CustomerService customerService) {
		this.customerService = customerService;
	}
	@CrossOrigin
	@GetMapping("/{referenceId}")
	public ResponseEntity<Customer> getCustomerDetails(@PathVariable("referenceId") String referenceId) {
		Customer customer = customerService.getCustomerDetails(referenceId);
		if (Objects.nonNull(customer)) {
			return ResponseEntity.ok(customer);
		}
		return ResponseEntity.notFound().build();
	}

}
